# OpenDeepWiki项目"代码仓库转换为知识文档"功能分析与迁移方案

## 一、项目核心功能实现分析

### 1. 整体架构
OpenDeepWiki是一个基于.NET 9的AI驱动代码知识库系统，采用前后端分离架构：
- **后端**：ASP.NET Core 9.0 + Entity Framework Core + Microsoft Semantic Kernel
- **前端**：React 19 + TypeScript + Vite
- **AI集成**：OpenAI API + 自定义Prompt系统

### 2. 核心功能关键代码位置

#### 仓库克隆和代码分析
- **GitService.cs** (`g:/projects/OpenDeepWiki/src/KoalaWiki/Git/GitService.cs`)
  - `CloneRepository()` 方法：负责克隆Git仓库到本地
  - `PullRepository()` 方法：拉取最新代码并获取提交记录

- **WarehouseService.cs** (`g:/projects/OpenDeepWiki/src/KoalaWiki/Services/WarehouseService.cs`)
  - `SubmitWarehouseAsync()` 方法：提交仓库信息到系统
  - `UploadAndSubmitWarehouseAsync()` 方法：上传压缩包并提交

#### AI生成文档核心逻辑
- **WarehouseProcessingTask.Analyse.cs** (`g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/WarehouseProcessingTask.Analyse.cs`)
  - `HandleAnalyseAsync()` 方法：核心文档生成入口
  - 使用AI分析代码变更并确定文档结构

- **DocumentPendingService.cs** (`g:/projects/OpenDeepWiki/src/KoalaWiki/KoalaWarehouse/DocumentPending/DocumentPendingService.cs`)
  - `HandlePendingDocumentsAsync()` 方法：批量处理文档生成
  - `ProcessDocumentAsync()` 方法：处理单个文档生成

#### 代码处理和压缩
- **CodeFileDetector.cs** (`g:/projects/OpenDeepWiki/framework/src/OpenDeepWiki.CodeFoundation/Utils/CodeFileDetector.cs`)
  - `IsCodeFile()` 方法：检测文件是否为代码文件
  - `GetLanguageType()` 方法：获取编程语言类型

- **CodeCompressionService.cs** (`g:/projects/OpenDeepWiki/framework/src/OpenDeepWiki.CodeFoundation/CodeCompressionService.cs`)
  - `CompressCode()` 方法：压缩代码内容，减少Token消耗

#### 文档生成和存储
- **DocumentCatalogService.cs** (`g:/projects/OpenDeepWiki/src/KoalaWiki/Services/DocumentCatalogService.cs`)
  - `GetDocumentCatalogsAsync()` 方法：获取文档目录结构
  - `GetDocumentByIdAsync()` 方法：获取具体文档内容

### 3. 核心Prompt位置和内容

#### 主要Prompt文件
- **Prompt.cs** ([`g:/projects/OpenDeepWiki/src/KoalaWiki/KoalaWarehouse/Prompt.cs`](g:/projects/OpenDeepWiki/src/KoalaWiki/KoalaWarehouse/Prompt.cs:1)) - 主要Prompt常量定义
- **PromptContext.cs** ([`g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/PromptContext.cs`](g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/PromptContext.cs:1)) - Prompt上下文管理和变量替换
- **GenerateDocs.md** ([`g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Warehouse/GenerateDocs.md`](g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Warehouse/GenerateDocs.md:1)) - 文档生成核心模板

#### 关键Prompt内容
1. **仓库分析Prompt** ([`Prompt.cs`](g:/projects/OpenDeepWiki/src/KoalaWiki/KoalaWarehouse/Prompt.cs:1) 中的 `AnalyzeNewCatalogue`)：分析Git提交记录，更新现有文档结构
2. **文档生成Prompt** ([`GenerateDocs.md`](g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Warehouse/GenerateDocs.md:1))：基于代码文件生成综合技术文档，支持多阶段生成流程
3. **项目分类Prompt** ([`RepositoryClassification.md`](g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Warehouse/RepositoryClassification.md:1))：对仓库进行智能分类
4. **聊天交互Prompt** ([`Responses.md`](g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Chat/Responses.md:1) 和 [`ResponsesDeepResearch.md`](g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Chat/ResponsesDeepResearch.md:1))：提供仓库取证和代码架构分析

#### 变量替换机制
- **双花括号语法**：`{{variable_name}}` - 用于Prompt.cs中的字符串替换
- **美元符号语法**：`{{$variable_name}}` - 用于Markdown模板文件中的变量替换
- **常用变量**：`{{$catalogue}}`、`{{$git_repository}}`、`{{$code_files}}`、`{{$title}}`等

### 4. 任务调度机制

#### 核心后台服务
- **WarehouseTask** (`g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/WarehouseTask.cs`)：处理仓库初始化和文档生成
- **WarehouseProcessingTask** (`g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/WarehouseProcessingTask.cs`)：处理仓库增量更新
- **StatisticsBackgroundService** (`g:/projects/OpenDeepWiki/src/KoalaWiki/Services/StatisticsBackgroundService.cs`)：生成统计数据
- **MiniMapBackgroundService** (`g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/MiniMapBackgroundService.cs`)：生成知识图谱

#### 任务状态管理
- **仓库状态**：Pending、Processing、Completed、Failed
- **同步状态**：InProgress、Success、Failed
- **翻译任务状态**：Pending、Running、Completed、Failed、Cancelled

#### 并发控制和错误处理
- **信号量控制**：使用SemaphoreSlim限制并发数（默认3个）
- **Polly重试策略**：指数退避重试，最大重试3次
- **超时控制**：文档处理任务设置30分钟超时

### 5. 完整流程数据流向

1. **仓库提交阶段**
   - 用户通过 `WarehouseService.SubmitWarehouseAsync()` 提交仓库URL
   - 系统验证仓库信息并创建仓库记录
   - 仓库状态设置为 `Pending`

2. **仓库克隆阶段**
   - `WarehouseProcessingTask` 后台服务检测到待处理仓库
   - 调用 `GitService.CloneRepository()` 克隆仓库到本地
   - 获取仓库基本信息（分支、提交记录等）

3. **代码分析阶段**
   - `HandleAnalyseAsync()` 方法分析代码变更
   - 使用AI分析提交记录和文件变更
   - 生成文档目录结构
   - 创建/更新 `DocumentCatalogs` 记录

4. **文档生成阶段**
   - `DocumentPendingService.HandlePendingDocumentsAsync()` 批量处理文档
   - 为每个目录创建独立的Kernel实例
   - 调用OpenAI API生成文档内容
   - 应用代码压缩和优化

5. **文档存储阶段**
   - 生成的文档内容保存到 `DocumentFileItems` 表
   - 记录源文件引用信息到 `DocumentFileItemSources` 表
   - 更新文档状态为 `Completed`

6. **多语言处理阶段**（可选）
   - `TranslateService` 生成多语言版本
   - 保存到 `DocumentCatalogI18ns` 和 `DocumentFileItemI18ns` 表

7. **增量更新阶段**
   - 定期检查仓库更新
   - 通过 `WarehouseSyncService` 同步变更
   - 重新生成受影响的文档

## 二、迁移到其它编排框架的具体实现方案

### 1. 迁移架构设计

#### 新系统架构
```
├─────────────────┤
│  Agent │  (RepositoryAnalysisAgent)
│                │  (DocumentGenerationAgent)
│                │  (TranslationAgent)
├─────────────────┤
│   任务编排层    │  (TaskOrchestrator)
├─────────────────┤
│     工具层      │  ( CodeTools, StorageTools)
├─────────────────┤
│    存储层       │  (PostgreSQL/Redis)
└─────────────────┘
```

### 2. Prompt复用方案

#### PromptManager实现
```python
class PromptManager:
    def __init__(self):
        self.prompts = self._load_prompts()
        self.variable_manager = PromptVariableManager()
        self.i18n_manager = MultiLanguagePromptManager()
    
    def get_prompt(self, prompt_name: str, variables: dict = None, language: str = "zh-CN"):
        template = self.prompts.get(prompt_name)
        if variables:
            template = self.variable_manager.replace_variables(template, variables)
        return self.i18n_manager.add_language_instruction(template, language)
```

#### 变量替换机制重新实现
```python
class PromptVariableManager:
    def replace_variables(self, template: str, variables: dict) -> str:
        result = template
        for key, value in variables.items():
            result = result.replace(f"{{{{${key}}}}}", str(value))
        return result
```

### 3. 任务调度重新设计

#### TaskOrchestrator实现
```python
class TaskOrchestrator:
    def __init__(self):
        self.task_queue = asyncio.Queue()
        self.concurrency_limiter = asyncio.Semaphore(3)
        self.state_manager = StateManager()
        self.error_handler = ErrorHandler()
    
    async def process_repository(self, repo_url: str):
        async with self.concurrency_limiter:
            try:
                # 创建任务链
                chain = (
                    self.repository_analysis_agent
                    | self.document_generation_agent
                    | self.translation_agent
                )
                
                # 执行任务链
                result = await chain.ainvoke({"repository_url": repo_url})
                await self.state_manager.update_task_status(repo_url, "completed")
                
            except Exception as e:
                await self.error_handler.handle_error(repo_url, e)
                await self.state_manager.update_task_status(repo_url, "failed")
```

#### 状态管理系统
```python
class StateManager:
    def __init__(self, storage_backend: str = "postgresql"):
        self.backend = self._get_backend(storage_backend)
        self.listeners = []
    
    async def update_task_status(self, task_id: str, status: str):
        await self.backend.update_task_status(task_id, status)
        await self._notify_listeners(task_id, status)
```

### 4. 核心Agent实现

#### RepositoryAnalysisAgent
```python
class RepositoryAnalysisAgent:
    def __init__(self):
        self.git_tools = GitTools()
        self.code_analyzer = CodeAnalyzer()
        self.prompt_manager = PromptManager()
    
    async def analyze_repository(self, repo_url: str) -> dict:
        # 克隆仓库
        repo_path = await self.git_tools.clone_repository(repo_url)
        
        # 分析代码结构
        code_structure = await self.code_analyzer.analyze_structure(repo_path)
        
        # 使用AI分析变更
        prompt = self.prompt_manager.get_prompt(
            "AnalyzeNewCatalogue",
            variables={
                "git_repository": repo_url,
                "catalogue": code_structure
            }
        )
        
        result = await self.llm.ainvoke(prompt)
        return {"analysis": result, "structure": code_structure}
```

#### DocumentGenerationAgent
```python
class DocumentGenerationAgent:
    def __init__(self):
        self.prompt_manager = PromptManager()
        self.code_compressor = CodeCompressor()
    
    async def generate_document(self, analysis_result: dict) -> str:
        # 压缩代码内容
        compressed_code = await self.code_compressor.compress_files(
            analysis_result["structure"]["files"]
        )
        
        # 生成文档
        prompt = self.prompt_manager.get_prompt(
            "GenerateDocs",
            variables={
                "title": analysis_result["structure"]["name"],
                "git_repository": analysis_result["repository_url"],
                "code_files": compressed_code
            }
        )
        
        result = await self.llm.ainvoke(prompt)
        return result
```

#### TranslationAgent
```python
class TranslationAgent:
    def __init__(self):
        self.prompt_manager = PromptManager()
        self.supported_languages = ["en-US", "ja-JP", "ko-KR", "zh-CN"]
    
    async def translate_document(self, document: str, target_language: str) -> str:
        prompt = self.prompt_manager.get_prompt(
            "TranslateDocument",
            variables={
                "document": document,
                "target_language": target_language
            },
            language=target_language
        )
        
        result = await self.llm.ainvoke(prompt)
        return result
```

### 5. 具体实现步骤

#### 第一阶段：准备阶段（2周）
1. 环境搭建和框架集成
   - 安装LangChain和相关依赖
   - 设置开发环境和CI/CD
   - 数据库设计和迁移

2. 基础工具类开发
   - GitTools实现
   - CodeAnalyzer实现
   - CodeCompressor实现

#### 第二阶段：核心组件迁移（2.5周）
1. Prompt系统迁移
   - PromptManager开发
   - PromptVariableManager实现
   - MultiLanguagePromptManager开发

2. Git服务重新实现
   - 仓库克隆功能
   - 代码分析功能
   - 变更检测功能

3. 任务调度器开发
   - TaskOrchestrator实现
   - StateManager开发
   - ErrorHandler开发

#### 第三阶段：Agent实现（3周）
1. RepositoryAnalysisAgent开发
   - 仓库分析逻辑
   - AI集成和Prompt调用
   - 结果处理和格式化

2. DocumentGenerationAgent开发
   - 文档生成逻辑
   - 多阶段生成流程
   - 质量检查和优化

3. TranslationAgent开发
   - 多语言翻译功能
   - 翻译质量保证
   - 批量翻译处理

#### 第四阶段：集成测试（2.5周）
1. 单元测试和集成测试
   - 各组件单元测试
   - 端到端集成测试
   - 性能基准测试

2. 性能测试和优化
   - 并发性能测试
   - 内存使用优化
   - API响应时间优化

3. 兼容性测试
   - 与原系统数据兼容性
   - API接口兼容性
   - 前端集成测试

#### 第五阶段：部署上线（1.5周）
1. 灰度发布
   - 小规模用户测试
   - 性能监控和调优
   - 问题修复和优化

2. 全量发布
   - 完整系统切换
   - 数据迁移验证
   - 用户培训和文档

3. 监控和优化
   - 系统监控设置
   - 性能指标跟踪
   - 持续优化改进

### 6. 风险评估和缓解措施

#### 主要风险
1. **Prompt兼容性**：现有Prompt可能需要调整以适应新框架
2. **性能影响**：新框架可能带来性能变化
3. **数据一致性**：迁移过程中可能出现数据不一致
4. **学习成本**：团队需要学习LangChain框架

#### 缓解措施
1. **双系统并行**：保持原系统运行，逐步切换
2. **充分测试**：完整的测试体系确保质量
3. **回滚机制**：快速回滚到原系统的能力
4. **团队培训**：提供LangChain框架培训和技术支持

### 7. 关键组件绝对路径总结

#### 后台服务核心
- `g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/WarehouseTask.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/WarehouseProcessingTask.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/WarehouseProcessingTask.Analyse.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/BackendService/WarehouseProcessingTask.Commit.cs`

#### 任务处理服务
- `g:/projects/OpenDeepWiki/src/KoalaWiki/KoalaWarehouse/DocumentPending/DocumentPendingService.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Generate/TranslateService.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Services/WarehouseSyncService.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Services/WarehouseSyncExecutor.cs`

#### Prompt系统
- `g:/projects/OpenDeepWiki/src/KoalaWiki/KoalaWarehouse/Prompt.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/PromptContext.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Warehouse/GenerateDocs.md`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Prompts/Warehouse/RepositoryClassification.md`

#### 代码处理工具
- `g:/projects/OpenDeepWiki/framework/src/OpenDeepWiki.CodeFoundation/Utils/CodeFileDetector.cs`
- `g:/projects/OpenDeepWiki/framework/src/OpenDeepWiki.CodeFoundation/CodeCompressionService.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Tools/FileTool.cs`
- `g:/projects/OpenDeepWiki/src/KoalaWiki/Tools/CodeAnalyzeTool.cs`

## 三、总结

本分析报告全面梳理了OpenDeepWiki项目"代码仓库转换为知识文档"功能的实现机制，并提供了详细的迁移方案。通过复用现有的高质量Prompt系统，结合LangChain框架的强大能力，可以实现更灵活、可扩展的文档生成系统。

### 核心发现
1. **系统架构清晰**：采用模块化设计，各组件职责明确
2. **Prompt系统完善**：包含多种类型的Prompt模板和变量替换机制
3. **任务调度合理**：基于状态机的任务管理，支持并发控制和错误恢复
4. **代码处理智能**：支持多种编程语言的识别和压缩优化

### 迁移优势
1. **技术栈现代化**：从.NET迁移到Python生态，获得更丰富的AI工具支持
2. **架构灵活性**：基于Agent的设计模式，更容易扩展和维护
3. **社区支持**：LangChain活跃的社区提供持续的技术支持
4. **成本优化**：更高效的资源利用和更低的维护成本

迁移方案具有高度可执行性，提供了分阶段的实施计划和风险控制措施，能够确保平滑迁移的同时提升系统能力和可维护性。